---
id: 622
title: 'Lecture at the National Institute for Advanced Studies, Bengaluru'
date: '2021-03-19T10:02:28-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=622'
permalink: /2021/03/19/lecture-at-the-national-institute-for-advanced-studies-bengaluru/
categories:
    - 'New publications'
---

<div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-3 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow"><figure class="wp-block-image size-large">![](https://sushrutaproject.org/wp-content/uploads/2021/03/Sanskrit-Language-and-its-traditions-poster-724x1024.jpeg)</figure></div><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">The NIAS in Bengaluru is running a lecture series entitled “Sanskrit Language &amp; its Traditions”. As part of this series, Dominik Wujastyk recently contributed a lecture on the History of Ayurveda. In the [last part](https://youtu.be/MYgtGuv89tM?t=4431) of the lecture, Prof. Wujastyk introduced and discussed the Sushruta Project.

</div></div>To