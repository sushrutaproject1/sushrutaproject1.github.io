---
id: 607
title: Published!
date: '2021-03-08T08:05:00-07:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=607'
permalink: /2021/03/08/published/
categories:
    - Announcements
---

It is a pleasure to announce that [the paper discussed in an earlier blog post](https://sushrutaproject.org/2020/10/03/new-article-by-andrey-klebanov-in-press/) has now been published:

<div class="zp-Zotpress zp-Zotpress-Bib wp-block-group" id="zotpress-6e201e6d62dd933546ef174be26737e3"> <span class="ZP_API_USER_ID" style="display: none;">2579494</span> <span class="ZP_ITEM_KEY" style="display: none;">{2579494:5BHQQJJZ}</span> <span class="ZP_COLLECTION_ID" style="display: none;"></span> <span class="ZP_TAG_ID" style="display: none;"></span> <span class="ZP_AUTHOR" style="display: none;"></span> <span class="ZP_YEAR" style="display: none;"></span> <span class="ZP_ITEMTYPE" style="display: none;"></span> <span class="ZP_INCLUSIVE" style="display: none;">1</span> <span class="ZP_STYLE" style="display: none;">chicago-author-date</span> <span class="ZP_LIMIT" style="display: none;">50</span> <span class="ZP_SORTBY" style="display: none;">default</span> <span class="ZP_ORDER" style="display: none;"></span> <span class="ZP_TITLE" style="display: none;"></span> <span class="ZP_SHOWIMAGE" style="display: none;"></span> <span class="ZP_SHOWTAGS" style="display: none;"></span> <span class="ZP_DOWNLOADABLE" style="display: none;"></span> <span class="ZP_NOTES" style="display: none;"></span> <span class="ZP_ABSTRACT" style="display: none;"></span> <span class="ZP_CITEABLE" style="display: none;"></span> <span class="ZP_TARGET" style="display: none;"></span> <span class="ZP_URLWRAP" style="display: none;"></span> <span class="ZP_FORCENUM" style="display: none;"></span> <span class="ZP_HIGHLIGHT" style="display: none;"></span> <span class="ZP_POSTID" style="display: none;">607</span> <span class="ZOTPRESS_PLUGIN_URL" style="display:none;">https://sushrutaproject.org/wp-content/plugins/zotpress/</span><div class="zp-List loading"><div class="zp-SEO-Content"> </div> </div> </div>