---
id: 979
title: 'Another project publication'
date: '2021-10-27T21:53:33-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=979'
permalink: /2021/10/27/another-project-publication/
categories:
    - Announcements
    - 'New publications'
---

<div class="wp-block-media-text alignwide is-stacked-on-mobile" style="grid-template-columns:45% auto"><figure class="wp-block-media-text__media">![](https://sushrutaproject.org/wp-content/uploads/2021/10/Screenshot-from-2021-10-27-21-48-56.png)</figure><div class="wp-block-media-text__content">We are pleased to announce a new open access project publication, “Ḍalhaṇa and the Early `Nepalese’ Version of the *Suśrutasaṃhitā*.” See <https://doi.org/10.20935/AL3733>

</div></div>