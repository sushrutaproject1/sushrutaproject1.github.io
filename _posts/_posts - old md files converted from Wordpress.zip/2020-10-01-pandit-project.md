---
id: 47
title: 'Pandit Project'
date: '2020-10-01T03:42:10-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'http://sushrutaproject.org/?p=47'
permalink: /2020/10/01/pandit-project/
categories:
    - Announcements
tags:
    - panditproject
---

We are collabrating with the Pandit Project as a place to keep track in a structured and relational manner of works, authors and especially manuscripts. Here is the [Pandit Project entry for the Suśrutasaṃhitā and its commentaries](https://www.panditproject.org/entity/42004/work).