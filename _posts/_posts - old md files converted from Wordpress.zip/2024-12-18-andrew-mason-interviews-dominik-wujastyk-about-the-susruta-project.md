---
id: 1674
title: 'Andrew Mason interviews Dominik Wujastyk about the Suśruta Project'
date: '2024-12-18T10:47:34-07:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=1674'
permalink: /2024/12/18/andrew-mason-interviews-dominik-wujastyk-about-the-susruta-project/
categories:
    - Announcements
---

In December 2024, I was interviewed by Andrew Mason, the researcher and publisher on South Asian alchemy and medicine and director of the [Netera publishing project](https://www.neterapublishing.com/).

Here’s the interview:

- <https://www.youtube.com/watch?v=1gvUDqAabOM>