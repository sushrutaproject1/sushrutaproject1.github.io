---
id: 921
title: 'Congratulations to Harshal Bhatt'
date: '2021-08-03T20:10:18-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=921'
permalink: /2021/08/03/congratulations-to-harshal-bhatt/
categories:
    - Announcements
---

We offer our sincere congratulations to our project Research Assitant, Harshal Bhatt, on his appointment as Assistant Professor at The Maharaja Sayajirao University of Baroda. For the next eleven months he will be teaching Sanskrit language and Siddhānta Kaumudī.