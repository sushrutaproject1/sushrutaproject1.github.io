---
id: 27
title: 'Day one of this project!'
date: '2020-04-10T21:51:18-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'http://sushrutaproject.org/?p=27'
permalink: /2020/04/10/day-one-of-this-project/
pagelayer-data:
    - '1601523793'
categories:
    - Announcements
---

Welcome to this brand new website! We just heard the news about our project funding yesterday (April 9, 2020). As we get started, you will find reports and news here about our progress. The project will start in earnest after September 2020. We look forward to keeping you interested and stimulated with discoveries about Ayurveda, Suśruta, South Asian manuscripts and the history of medicine.