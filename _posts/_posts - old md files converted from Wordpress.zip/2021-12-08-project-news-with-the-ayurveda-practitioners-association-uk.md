---
id: 1055
title: 'Ayurveda Practitioners Association, UK'
date: '2021-12-08T16:38:39-07:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=1055'
permalink: /2021/12/08/project-news-with-the-ayurveda-practitioners-association-uk/
categories:
    - Announcements
---

<div class="wp-block-group alignwide"><div class="wp-block-group__inner-container is-layout-flow wp-block-group-is-layout-flow"><div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-7 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:100%"><div class="wp-block-image"><figure class="alignleft is-resized">![](https://sushrutaproject.org/wp-content/uploads/2021/12/p1.png)</figure></div><div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-6 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">The Winter 2021 issue of the Newsletter of the [APA](http://apa.uk.com) has just appeared.

</div></div></div></div></div></div><div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-10 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:100%"><div class="wp-block-columns alignwide is-layout-flex wp-container-core-columns-is-layout-8 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:50%"></div><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:50%"></div></div><div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-9 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow"><figure class="wp-block-image size-full">![](https://sushrutaproject.org/wp-content/uploads/2021/12/p9.png)</figure></div><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">Thanks to the editor, Andrew Mason, for including a spot on the Suśruta Project (pp. 9-10)

</div></div></div></div>