---
id: 934
title: 'New project publication'
date: '2021-08-21T10:42:07-06:00'
author: 'Dominik Wujastyk'
layout: post
guid: 'https://sushrutaproject.org/?p=934'
permalink: /2021/08/21/new-project-publication/
categories:
    - Announcements
    - 'New publications'
---

<div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-4 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:50%"></div></div><div class="wp-block-columns is-layout-flex wp-container-core-columns-is-layout-5 wp-block-columns-is-layout-flex"><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow"><figure class="wp-block-image size-full is-style-rounded">[![](https://sushrutaproject.org/wp-content/uploads/2021/08/Screenshot-from-2021-08-22-09-52-15.png)](http://doi.org/10.20935/al2992)</figure></div><div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">We are pleased to announce a new open access project publication, “Further Insight into the Role of Dhanvantari, the Physician to the Gods, in the Suśrutasaṃhitā.”

- <http://doi.org/10.20935/al2992>

</div></div>